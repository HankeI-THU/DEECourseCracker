#include<stdio.h>
#include<string.h>
#include<stdlib.h>
void main()
{
	void addd(FILE*fp[20][20],float a[10][10],float b[10][10],int m1,int m2,int n1,int n2);
	void subb(FILE*fp[20][20],float a[10][10],float b[10][10],int m1,int m2,int n1,int n2);
	void mull(FILE*fp[20][20],float a[10][10],float b[10][10],int m1,int m2,int n1,int n2);
	FILE* fp1,*fp2,*fp3,*fp4,*fp_info;
	FILE* fp_add[20][20],*fp_sub[20][20],*fp_mul[20][20];
	char add_name[5][5][20],sub_name[5][5][20],mul_name[5][5][20];
	char vary_add_i[12],vary_add_j[12];
	char vary_sub_i[12],vary_sub_j[12];
	char vary_mul_i[12],vary_mul_j[12];
	float a[5][10][10];
	int i,j,m[5],n[5],l;
	int add=0, add_1[20],add_2[20];
	int sub=0, sub_1[20],sub_2[20];
	int mul=0, mul_1[20],mul_2[20];
	if((fp1=fopen(".\\matrix_1.txt","r"))==NULL)
	{
		printf("1error!");
		exit(0);
	}
	if((fp2=fopen(".\\matrix_2.txt","r"))==NULL)
	{
		printf("2error!");
		exit(0);
	}
	if((fp3=fopen(".\\matrix_3.txt","r"))==NULL)
	{
		printf("3error!");
		exit(0);
	}
	if((fp4=fopen(".\\matrix_4.txt","r"))==NULL)
	{
		printf("4error!");
		exit(0);
	}
	if((fp_info=fopen(".\\info.txt","w"))==NULL)
	{
		printf("info_error!");
		exit(0);
	}
	fscanf(fp1,"%d %d",&m[1],&n[1]);
	for(i=0;i<m[1];i++)
	{
		for(j=0;j<n[1];j++)
		{
			fscanf(fp1,"%f",&a[1][i][j]);
		}
	}
	fscanf(fp2,"%d %d",&m[2],&n[2]);
	for(i=0;i<m[2];i++)
	{
		for(j=0;j<n[2];j++)
		{
			fscanf(fp2,"%f",&a[2][i][j]);
		}
	}
	fscanf(fp3,"%d %d",&m[3],&n[3]);
	for(i=0;i<m[3];i++)
	{
		for(j=0;j<n[3];j++)
		{
			fscanf(fp3,"%f",&a[3][i][j]);
		}
	}
	fscanf(fp4,"%d %d",&m[4],&n[4]);
	for(i=0;i<m[4];i++)
	{
		for(j=0;j<n[4];j++)
		{
			fscanf(fp4,"%f",&a[4][i][j]);
		}
	}
	for(i=1;i<=4;i++)
	{
		for(j=1;j<=4;j++)
		{
			if(m[i]==m[j]&&n[i]==n[j])
			{
				fprintf(fp_info,"%d��%d����������\n",i,j);
				add++;
				add_1[add]=i,add_2[add]=j;
			}
		}
	}
	for(l=1;l<=add;l++)
	{
		strcpy(add_name[add_1[l]][add_2[l]],"add_");
		sprintf(vary_add_i,"%d_",add_1[l]);
		strcat(add_name[add_1[l]][add_2[l]],vary_add_i);
		sprintf(vary_add_j,"%d",add_2[l]);
		strcat(add_name[add_1[l]][add_2[l]],vary_add_j);
		strcat(add_name[add_1[l]][add_2[l]],".txt");
	}
    for(l=1;l<=add;l++)
	{
		fp_add[m[add_1[l]]][m[add_2[l]]]=fopen(add_name[add_1[l]][add_2[l]],"w");
		fprintf(fp_add[m[add_1[l]]][m[add_2[l]]],"%d %d\n",m[add_1[l]],n[add_2[l]]);
		addd(fp_add,a[add_1[l]],a[add_2[l]],m[add_1[l]],m[add_2[l]],n[add_1[l]],n[add_2[l]]);
	}
	for(i=1;i<=4;i++)
	{
		for(j=1;j<=4;j++)
		{
			if(m[i]==m[j]&&n[i]==n[j])
			{
				fprintf(fp_info,"%d��%d����������\n",i,j);
				sub++;
				sub_1[sub]=i,sub_2[sub]=j;
			}
		}
	}
		for(l=1;l<=sub;l++)
	{
		strcpy(sub_name[sub_1[l]][sub_2[l]],"sub_");
		sprintf(vary_sub_i,"%d_",sub_1[l]);
		strcat(sub_name[sub_1[l]][sub_2[l]],vary_sub_i);
		sprintf(vary_sub_j,"%d",sub_2[l]);
		strcat(sub_name[sub_1[l]][sub_2[l]],vary_sub_j);
		strcat(sub_name[sub_1[l]][sub_2[l]],".txt");
	}
	for(l=1;l<=sub;l++)
	{
	    fp_sub[m[sub_1[l]]][m[sub_2[l]]]=fopen(sub_name[sub_1[l]][sub_2[l]],"w");
		fprintf(fp_sub[m[sub_1[l]]][m[sub_2[l]]],"%d %d\n",m[sub_1[l]],n[sub_1[l]]);
		subb(fp_sub,a[sub_1[l]],a[sub_2[l]],m[sub_1[l]],m[sub_2[l]],n[sub_1[l]],n[sub_2[l]]);
		}
	for(i=1;i<=4;i++)
	{
		for(j=1;j<=4;j++)
		{
			if(n[i]==m[j])
			{
				mul++;
				mul_1[mul]=i;
				mul_2[mul]=j;
			}
		}
	}
	    for(l=1;l<=mul;l++)
	{
		strcpy(mul_name[mul_1[l]][mul_2[l]],"mul_");
		sprintf(vary_mul_i,"%d_",mul_1[l]);
		strcat(mul_name[mul_1[l]][mul_2[l]],vary_mul_i);
		sprintf(vary_mul_j,"%d",mul_2[l]);
		strcat(mul_name[mul_1[l]][mul_2[l]],vary_mul_j);
		strcat(mul_name[mul_1[l]][mul_2[l]],".txt");
	}
	for(i=1;i<=mul;i++)
		fprintf(fp_info,"%d��%d����������\n",mul_1[i],mul_2[i]);
	for(i=1;i<=mul;i++)
	{
	    fp_mul[m[mul_1[i]]][m[mul_2[i]]]=fopen(mul_name[mul_1[i]][mul_2[i]],"w");
		fprintf(fp_mul[m[mul_1[i]]][m[mul_2[i]]],"%d %d\n",m[mul_1[i]],n[mul_2[i]]);
		mull(fp_mul,a[mul_1[i]],a[mul_2[i]],m[mul_1[i]],m[mul_2[i]],n[mul_1[i]],n[mul_2[i]]);
	}
	    for(i=1;i<=4;i++)
		for(j=1;j<=4;j++)
		{
			if(m[i]!=m[j]||n[i]!=n[j]&&i!=j)
				fprintf(fp_info,"%d��%d���󲻿������\n",i,j);

		}
		for(i=1;i<=4;i++)
		for(j=1;j<=4;j++)
		{
			if(m[i]!=m[j]||n[i]!=n[j]&&i!=j)
				fprintf(fp_info,"%d��%d���󲻿������\n",i,j);

		}
		for(i=1;i<=4;i++)
		for(j=1;j<=4;j++)
		{
			if(n[i]!=m[j]||i==j&&m[i]!=m[i])
				fprintf(fp_info,"%d��%d���󲻿������\n",i,j);
		}
}
void addd(FILE*fp[20][20],float a[10][10],float b[10][10],int m1,int m2,int n1,int n2)
{
	for(int i=0;i<m1;i++)
	{
		for(int j=0;j<n1;j++)
		{
			fprintf(fp[m1][m2],"%.3f ",a[i][j]+b[i][j]);
		}
		fprintf(fp[m1][m2],"\n");
	}
	fprintf(fp[m1][m2],"\n");
}
void subb(FILE*fp[20][20],float a[10][10],float b[10][10],int m1,int m2,int n1,int n2)
{
	for(int i=0;i<m1;i++)
	{
		for(int j=0;j<n1;j++)
		{
			fprintf(fp[m1][m2],"%.3f ",a[i][j]-b[i][j]);
		}
		fprintf(fp[m1][m2],"\n");
	}
	fprintf(fp[m1][m2],"\n");
}
void mull(FILE*fp[20][20],float a[10][10],float b[10][10],int m1,int m2,int n1,int n2)
{
	float c[10][10];
	int j,l,k;
	for(j=0;j<m1;j++)
		{
			for(l=0;l<n2;l++)
			{
				c[j][l]=0;
			}
		}
			for(j=0;j<m1;j++)
		{
			for(l=0;l<n2;l++)
			{
				c[j][l]=0;
				for(k=0;k<n1;k++)
				{c[j][l]+=a[j][k]*b[k][l];}
			}
		}

	for(j=0;j<m1;j++)
		{
			{
			for(l=0;l<n2;l++)
			{
			fprintf(fp[m1][m2],"%.3f ",c[j][l]);
			}
			fprintf(fp[m1][m2],"\n");
			}		
		}
		fprintf(fp[m1][m2],"\n");
	}
