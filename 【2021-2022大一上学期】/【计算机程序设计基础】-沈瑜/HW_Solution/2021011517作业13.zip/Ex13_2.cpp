#include<stdio.h>
#include<stdlib.h>
#include<string.h>
int main()
{
	FILE *fp,*fq,*fr;
	int q,w,r,i,j;
	char a[5],b[5],c[50],d[11][50],e[11][50];
	char s[3][10];
		if((fq=fopen(".\\TiaoKe.txt","r"))==NULL)
	{
		printf("error");
		exit(0);
	}
		for(i=0;i<=2;i++)
			fgets(s[i],10,fq);
		for(i=0;i<=2;i++){
		if(strlen(s[i])==7)
			{q=(int)s[i][1]-48;
		w=(int)s[i][5]-48;}
		if(strlen(s[i])==6)
			r=(int)s[i][1]-48;}

	if((fp=fopen(".\\KeBiao_input.txt","r"))==NULL)
	{
		printf("error");
		exit(0);
	}
	
	fscanf(fp,"%s %s %s",a,b,c);
	for(i=0;i<11;i++)
	{
		fgets(d[i],50,fp);}
	for(j=1;j<11;j++)
	{
		e[j][1]=d[j][1];
		if ((int)e[j][1]==q+48)
			d[j][1]=w+48;
	    if ((int)e[j][1]==w+48)
			d[j][1]=q+48;
		 if ((int)e[j][1]==r+48)
		 d[j][0]='\0';
	}
	if((fr=fopen(".\\KeBiao_Modified.txt","w"))==NULL)
	{ 
		printf("error");
		exit(0);
	}
	fprintf(fr,"%s %s %s\n%s%s%s%s%s%s%s%s%s%s",a,b,c,d[1],d[2],d[3],d[4],d[5],d[6],d[7],d[8],d[9],d[10]);
	return 0;
}
