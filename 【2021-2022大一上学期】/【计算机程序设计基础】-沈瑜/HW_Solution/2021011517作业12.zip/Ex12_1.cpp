#include<stdio.h>
#include<string.h>
void main()
{
	char arr1[10]="boynextdo";
	char arr2[10];
	void reverse_string(const char* str_in,char* str_out);
    reverse_string(arr1,arr2);
	printf("%s\n%s\n",arr1,arr2);

}
void reverse_string(const char *str_in,char *str_out)
{int i=strlen(str_in)-1,j=0;
char *out=str_out;
for(j=0;j<=i;j++,out++)
{*out=str_in[i-j];}
*out='\0';
}